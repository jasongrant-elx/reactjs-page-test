# My React Site

A landing page built with React + Vite, ready to develop in GitHub Codespaces,
tested with Vitest, checked by CI, and deployed to GitHub Pages.

All the text (name, tagline, features, pricing, FAQ) lives in
**`src/siteConfig.js`**. Colors live at the top of **`src/index.css`**.
Change those two files first to make the site yours.

## 1. Create the repo and push this code

1. On GitHub, click **New repository**. Name it (e.g. `my-react-site`), leave
   "Add a README" **unchecked**, and create it.
2. Unzip this project, then from inside the folder run:

   ```bash
   git init -b main          # skip if the folder already has a .git directory
   git add .
   git commit -m "Initial site"
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```

   No terminal handy? On the empty repo page, click **uploading an existing
   file** and drag in the unzipped files. Note that hidden folders
   (`.github`, `.devcontainer`) may not upload by drag-and-drop on some
   systems; if they are missing, use Codespaces to add them, or push with git.

## 2. Open it in a Codespace

On the repo page: **Code → Codespaces → Create codespace on main**.

The dev container installs Node 22 and runs `npm ci` automatically. When it
finishes, in the terminal run:

```bash
npm run dev
```

Codespaces forwards port 5173 and opens the site in a browser tab. Edits to
files reload instantly.

## 3. Everyday commands

| Command            | What it does                               |
| ------------------ | ------------------------------------------ |
| `npm run dev`      | Start the dev server (port 5173)           |
| `npm test`         | Run the tests once                         |
| `npm run test:watch` | Re-run tests as you edit                 |
| `npm run lint`     | Check code style with ESLint               |
| `npm run build`    | Build the production site into `dist/`     |
| `npm run preview`  | Serve the built site locally (port 4173)   |

Tests live next to the code (`src/App.test.jsx`). If you change the page
structure, update or add tests there.

## 4. Turn on GitHub Pages (one time)

1. Repo **Settings → Pages**.
2. Under **Build and deployment → Source**, choose **GitHub Actions**.

## 5. Deploy

Every push to `main` runs **Deploy to GitHub Pages (staging)**
(`.github/workflows/deploy.yml`). It tests, builds, and publishes to:

```
https://<your-username>.github.io/<repo-name>/
```

You can also run it by hand: **Actions → Deploy to GitHub Pages (staging) →
Run workflow**. The live URL appears on the workflow run summary.

Notes:
- The workflow sets Vite's `base` to `/<repo-name>/` automatically, so assets
  load correctly on Pages. If you name the repo `<your-username>.github.io`,
  it uses `/` instead.
- `404.html` is a copy of `index.html`, so client-side routes still load if
  you add a router later.

## CI

`.github/workflows/ci.yml` runs lint, tests, and build on every push and pull
request. A red ❌ on a commit means one of those failed; click it to see why.

## Project layout

```
.devcontainer/devcontainer.json   Codespaces setup
.github/workflows/ci.yml          Lint + test + build
.github/workflows/deploy.yml      GitHub Pages deploy
src/siteConfig.js                 ← all site copy
src/index.css                     ← theme colors and styles
src/components/                   Page sections
src/App.test.jsx                  Tests
```
