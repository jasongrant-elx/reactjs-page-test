import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from './App.jsx'
import { site, features, plans } from './siteConfig.js'
import { displayPrice } from './components/pricing.js'

describe('App', () => {
  it('renders the hero tagline from siteConfig', () => {
    render(<App />)
    expect(screen.getByRole('heading', { level: 1, name: site.tagline })).toBeInTheDocument()
  })

  it('renders one card per feature', () => {
    render(<App />)
    for (const f of features) {
      expect(screen.getByRole('heading', { name: f.title })).toBeInTheDocument()
    }
  })

  it('has navigation links to each section', () => {
    render(<App />)
    const nav = screen.getByRole('navigation', { name: 'Main' })
    expect(nav.querySelector('a[href="#pricing"]')).not.toBeNull()
  })

  it('toggles the mobile menu', async () => {
    render(<App />)
    const toggle = screen.getByRole('button', { name: 'Toggle menu' })
    expect(toggle).toHaveAttribute('aria-expanded', 'false')
    await userEvent.click(toggle)
    expect(toggle).toHaveAttribute('aria-expanded', 'true')
  })

  it('switches pricing to yearly', async () => {
    render(<App />)
    const pro = plans.find((p) => p.highlighted)
    const price = screen.getByTestId(`price-${pro.name}`)
    expect(price).toHaveTextContent(pro.price)
    await userEvent.click(screen.getByRole('button', { name: /yearly/i }))
    expect(price).toHaveTextContent(displayPrice(pro.price, true))
  })
})

describe('displayPrice', () => {
  it('discounts dollar prices by 20% when yearly', () => {
    expect(displayPrice('$20', true)).toBe('$16')
    expect(displayPrice('$20', false)).toBe('$20')
  })

  it('leaves free and custom prices unchanged', () => {
    expect(displayPrice('$0', true)).toBe('$0')
    expect(displayPrice('Custom', true)).toBe('Custom')
  })
})
