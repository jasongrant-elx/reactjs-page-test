// Edit this file to make the site yours: name, copy, features, pricing, FAQ.
// Everything on the page reads from here.

export const site = {
  name: 'Nova',
  tagline: 'Turn busywork into done work.',
  description:
    'Nova is a placeholder product that helps small teams automate repetitive tasks with AI. Replace this text with what your product does.',
  primaryCta: { label: 'Get started free', href: '#pricing' },
  secondaryCta: { label: 'See how it works', href: '#how-it-works' },
  contactEmail: 'hello@example.com',
}

export const nav = [
  { label: 'Features', href: '#features' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'FAQ', href: '#faq' },
]

export const stats = [
  { value: '10x', label: 'faster first drafts' },
  { value: '5 min', label: 'to set up' },
  { value: '24/7', label: 'always on' },
]

export const features = [
  { icon: '⚡', title: 'Instant automations', text: 'Describe a task in plain words and get a working workflow in seconds.' },
  { icon: '🧠', title: 'Learns your style', text: 'Outputs adapt to your tone, templates, and past decisions over time.' },
  { icon: '🔗', title: 'Connects your tools', text: 'Plug into the apps you already use without writing any code.' },
  { icon: '🔒', title: 'Private by default', text: 'Your data stays yours. Nothing is shared or used for training.' },
  { icon: '📊', title: 'Clear reporting', text: 'See what ran, what it saved you, and what needs your attention.' },
  { icon: '🤝', title: 'Built for teams', text: 'Share workflows, set permissions, and review changes together.' },
]

export const steps = [
  { title: 'Describe', text: 'Tell Nova what you want done, in your own words.' },
  { title: 'Review', text: 'Check the suggested workflow and tweak anything you like.' },
  { title: 'Automate', text: 'Turn it on and let it run. Get a summary when it is done.' },
]

export const plans = [
  { name: 'Starter', price: '$0', period: '/month', features: ['3 workflows', '100 runs per month', 'Community support'], cta: 'Start free' },
  { name: 'Pro', price: '$19', period: '/month', features: ['Unlimited workflows', '5,000 runs per month', 'Priority support', 'Team sharing'], cta: 'Start trial', highlighted: true },
  { name: 'Business', price: 'Custom', period: '', features: ['Unlimited everything', 'SSO and audit logs', 'Dedicated success manager'], cta: 'Contact us' },
]

export const faqs = [
  { q: 'Do I need to know how to code?', a: 'No. Everything is set up by describing what you want in plain language.' },
  { q: 'Can I cancel anytime?', a: 'Yes. Plans are month to month and you can cancel from your settings.' },
  { q: 'Is there a free plan?', a: 'Yes. The Starter plan is free forever with sensible limits.' },
]
