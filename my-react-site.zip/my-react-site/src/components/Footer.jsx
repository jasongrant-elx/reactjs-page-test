import { site } from '../siteConfig.js'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <span>
          © {new Date().getFullYear()} {site.name}. All rights reserved.
        </span>
        <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a>
      </div>
    </footer>
  )
}
