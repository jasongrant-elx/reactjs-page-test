import { faqs } from '../siteConfig.js'

export default function Faq() {
  return (
    <section className="section section-alt" id="faq">
      <div className="container narrow">
        <h2 className="section-title">Questions, answered</h2>
        {faqs.map((f) => (
          <details className="faq" key={f.q}>
            <summary>{f.q}</summary>
            <p>{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  )
}
