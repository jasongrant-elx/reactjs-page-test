import { features } from '../siteConfig.js'

export default function Features() {
  return (
    <section className="section" id="features">
      <div className="container">
        <h2 className="section-title">Everything you need</h2>
        <p className="section-sub">Swap these cards for the real benefits of your product.</p>
        <div className="grid">
          {features.map((f) => (
            <article className="card" key={f.title}>
              <div className="card-icon" aria-hidden="true">{f.icon}</div>
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
