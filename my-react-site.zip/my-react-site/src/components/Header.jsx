import { useState } from 'react'
import { site, nav } from '../siteConfig.js'

export default function Header() {
  const [open, setOpen] = useState(false)
  return (
    <header className="header">
      <div className="container header-inner">
        <a href="#top" className="logo">
          <span className="logo-mark" aria-hidden="true">{site.name[0]}</span>
          {site.name}
        </a>
        <button
          className="menu-toggle"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          ☰
        </button>
        <nav className={open ? 'nav open' : 'nav'} aria-label="Main">
          {nav.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setOpen(false)}>
              {item.label}
            </a>
          ))}
          <a className="btn btn-primary btn-sm" href={site.primaryCta.href}>
            {site.primaryCta.label}
          </a>
        </nav>
      </div>
    </header>
  )
}
