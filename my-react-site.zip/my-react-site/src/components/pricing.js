// Yearly billing shows a 20% discount on numeric dollar prices.
export function displayPrice(price, yearly) {
  if (!yearly || !price.startsWith('$')) return price
  const n = Number(price.slice(1))
  if (!n) return price
  return `$${Math.round(n * 0.8)}`
}
