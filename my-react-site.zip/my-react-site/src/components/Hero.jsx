import { site, stats } from '../siteConfig.js'

export default function Hero() {
  return (
    <section className="hero" id="top">
      <div className="container hero-inner">
        <span className="pill">New · Placeholder announcement</span>
        <h1>{site.tagline}</h1>
        <p className="lead">{site.description}</p>
        <div className="cta-row">
          <a className="btn btn-primary" href={site.primaryCta.href}>{site.primaryCta.label}</a>
          <a className="btn btn-ghost" href={site.secondaryCta.href}>{site.secondaryCta.label}</a>
        </div>
        <ul className="stats">
          {stats.map((s) => (
            <li key={s.label}>
              <strong>{s.value}</strong>
              <span>{s.label}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
