import { useState } from 'react'
import { plans } from '../siteConfig.js'
import { displayPrice } from './pricing.js'

export default function Pricing() {
  const [yearly, setYearly] = useState(false)
  return (
    <section className="section" id="pricing">
      <div className="container">
        <h2 className="section-title">Simple pricing</h2>
        <div className="toggle" role="group" aria-label="Billing period">
          <button className={!yearly ? 'active' : ''} aria-pressed={!yearly} onClick={() => setYearly(false)}>
            Monthly
          </button>
          <button className={yearly ? 'active' : ''} aria-pressed={yearly} onClick={() => setYearly(true)}>
            Yearly (save 20%)
          </button>
        </div>
        <div className="grid grid-3">
          {plans.map((p) => (
            <article className={p.highlighted ? 'card plan featured' : 'card plan'} key={p.name}>
              {p.highlighted && <span className="badge">Most popular</span>}
              <h3>{p.name}</h3>
              <p className="price" data-testid={`price-${p.name}`}>
                {displayPrice(p.price, yearly)}
                <small>{p.period}</small>
              </p>
              <ul>
                {p.features.map((f) => (
                  <li key={f}>✓ {f}</li>
                ))}
              </ul>
              <a className={p.highlighted ? 'btn btn-primary' : 'btn btn-ghost'} href="#top">
                {p.cta}
              </a>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
